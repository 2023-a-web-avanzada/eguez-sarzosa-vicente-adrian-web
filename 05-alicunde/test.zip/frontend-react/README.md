# Test

To run the app follow these steps:

```bash
$ npm i
$ npm run dev
```

The app will be available on: [http://localhost:3000](http://localhost:3000)